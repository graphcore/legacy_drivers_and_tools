 =============================
Upgrading to v1.4.x
=============================

Icuflash tool information
-------------------------
This contains very important information about the icuflash tool and the upgrade
process, please read it before continuing.

* Icuflash does not depend on external FW images. It is a stand-alone executable.

* Icuflash only supports flowers_rev2 and flowers_rev3 b0 silicon boards.

* There are several versions of the 'icuflash' tool.
  Each version can be used for flashing a particular FW version.
  The 'icuflash' version matches the FW version it can flash.
  For example,'icuflash' v1.4.14 can be used to flash the v1.4.14 firmware.

* This will only work over PCIe

* This will only work if you have 2 IPU's that are classified as a MultiIPU. It won't work on a card that contains a single IPU

* After upgrading a board (or boards), perform a reboot of the chassis.

* The firmware contained within icuflash is signed by Graphcore RSA assymetric
  keys.  The public keys are also contained within and must be installed to the
  board during the update process.  The keys contained within are also signed
  and therefore any attempt to install these keys onto a board that contain any
  non-genuine public keys will not work. **See section: Compatibility between the
  firmware and the public keys**

* You can revoke keys already installed onto a card.  However you can never have
  two revoked keys on a card at the same time.  You must install a new key before
  revoking an alternate key.  This is to prevent no keys being available for
  updating firmware or keys.

* The key update mechanism supports the use of an external key file.  This is
  to allow a key update in the event of a compromise without releasing a tool
  update.  Note that any key file must be signed with Graphcore private keys
  corresponding to at least one installed public key before it will be accepted.

* There are two firmware images stored in the ICU flash memory.  Whilst it is
  not necessary to update both images to the v1.4.X version it is recommended
  that both images are updated.

* To upgrade from v1.3.XX to v1.4.XX requires the following ordered steps

  1) Install one of the two v1.4.XX images to the ICU and reboot into it.  This
     image has not been verified.
  2) Install both public keys to the ICU.  This is achieved by installing one
     key at a time. The primary key must be installed first, followed by the
     backup key. There is no need reboot when installing keys.
  3) Install the other of the two v1.4.XX image to the ICU and reboot into it.
     This upload will be verified by the newly installed public keys.
  4) Note that by booting the second verified image will cause the initial v1.4.XX
     image in step(1) that was not verified to be deleted.
  5) Therefore you must re-install the original upgrade image to v1.4.XX.  Both
     images are now complete and verifed.


Before Starting
---------------
Check that the following requirements are met before starting the upgrade
process:

* Ensure the card is running v1.3.28 or v1.3.31 firmware

* Ensure you have a Graphcore Drivers package installed.
  - To ensure a device driver is loaded and active (linux - kernel module).

* Ensure that the card is either flowers_rev2 or flowers_rev3 b0

* Ensure that you do NOT have the Graphcore host runtime libraries in your path,
i.e. you have NOT run ./enable in the driver directory. The icuflash tool must
be installed only with libipu_user.so that is supplied co-located in the same directory.


Compatibility between the contained firmware and public keys
------------------------------------------------------------
The firmware images and keys contained within the icuflash tool are compatible
with each other.

That is, both firmware images were signed with the private key that corresponds
to the primary public key contained within this tool. Therefore, when upgrading
from 1.3 for the first time, you must add the this internal key at the
appropriate point in the upgrade path.

In addition, notice that the secondary key contained in the ICU Update Tool must
be signed by the private key that corresponds to the primary one. Otherwise, it
won't be possible to install both of them.

The icuflash tool also provides a mechanism for installing a different set of
keys via a keyblob file. These keys may not be compatible with the firmware
contained within this tool and therefore should not be used during an upgrade
to 1.4 for the first time. The external key mechanism is provided for occasions
when the original private/public key pairs have expired, or when it is found
that a private key has been compromised. This allows for new keys to be issued
without needing to release or build a new version of icuflash.


Running the tool / understanding the input arguments
----------------------------------------------------
You can remove the `-f` from the flash commands to perform a 'dryrun'.
This will execute up to the point before flashing the image.
This can be useful to double check the correct image and version will be flashed before doing it.

The options `-d` and `-a` cannot be used together.

The option `d` can only specify one board.

**ICU Update Tool keys:** The ICU Update Tool can update the public keys in two
different ways:

1. Using its internal keys: The tool contains a pair of public keys embedded
   within it. These are called 'internal keys'. You can update the FW keys with
   these keys by using the `-k` option (see below).

2. Using a external keyblob binary file: The FW keys can be updated by providing
   an external keyblob binary file. This is achieved by using the `--input-key`
   option (see below).


Display help and allowed options::

      ./icuflash -h

Display help and allowed options for subcommands::

      ./icuflash <commmand> -h, where <command> is one of device, keys, image.

List the device id's of all the cards::

      ./icuflash device -l

Get the tool version number::

      ./icuflash --version

For upgrading all cards in parallel, execute::

      ./icuflash image -a -f

For upgrading a specific card, execute::

      ./icuflash image -d <device_id> -f

To perform a dryrun, remove the flash argumentt::

      ./icuflash image -d <device_id>

For a verbose output on any command::

      ./icuflash image -d <device_id> -v -f

For installing the Primary public key (internal) in parallel::

      ./icuflash keys --update -k 0 -a -f

For installing the Backup public key (internal) in parallel::

      ./icuflash keys --update -k 1 -a -f

For installing the Primary public key (internal) for a specific card::

      ./icuflash keys --update -k 0 -d <device_id> -f

For installing the Backup public key (internal) for a specific card::

      ./icuflash keys --update -k 1 -d <device_id> -f

For reading the installed public keys in parallel::

      ./icuflash keys --read -a -f

For reading the installed public key for a specific card::

      ./icuflash keys --read -d <device_id> -f

      UNSUPPORTED: This command is not supported in v1.4.12.

For revoking the installed Primary public key in parallel::

      Command not yet supported

For revoking the installed Backup public key in parallel::

      Command not yet supported

For revoking the installed Primary public key for a specific card::

      ./icuflash keys --delete -k 0 -d <device_id> -f

For revoking the installed Backup public key for a specific card::

      ./icuflash keys --delete -k 1 -d <device_id> -f


Installing the FW keys using an external keyblob binary file
-------------------------------------------------------------
For installing the a Graphcore key using an external keyblob binary file, you
can use the same commands as above, but adding the `--input-key` parameter
followed by the path to the keyblob file.

Remember that the running FW has two public keys (primary, backup) so, apart
from providing the external keyblob file, you need to specify which of the two
keys will be overwritten.

For instance, to update the key 0 of a board with ID <device_id> with a keyblob
binary file called `mysignedkeyblob.bin`, do:

      ./icuflash keys --update -k 0 -d <device_id> -f -i mysignedkeyblob.bin

Notice that `mysignedkeyblob.bin` contains a **signed key** (key +
ceritificate).

Something similar can be done to update all boards with an external key:

      ./icuflash keys --update -k 1 -a -f -i mysignedkeyblob.bin
